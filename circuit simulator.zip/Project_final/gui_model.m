
function varargout = gui_model(varargin)

% GUI_MODEL MATLAB code for gui_model.fig
%      GUI_MODEL, by itself, creates a new GUI_MODEL or raises the existing
%      singleton*.
%
%      H = GUI_MODEL returns the handle to a new GUI_MODEL or the handle to
%      the existing singleton*.
%
%      GUI_MODEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_MODEL.M with the given input arguments.
%
%      GUI_MODEL('Property','Value',...) creates a new GUI_MODEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_model_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_model_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_model

% Last Modified by GUIDE v2.5 16-Sep-2019 10:45:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_model_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_model_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_model is made visible.
function gui_model_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_model (see VARARGIN)


ha=axes('units','normalized',...
    'position',[0 0 1 1]);
Imm=imread('Ec1.png');
hi=imagesc(Imm)


% Choose default command line output for gui_model
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_model wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_model_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton2.

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1

% --- Executes during object creation, after setting all properties.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [filename pathname]=uigetfile({'*.txt'},'File selector');
    fullpathname=strcat(pathname,filename);
    text=fileread(fullpathname)
    
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




Value=get(handles.popupmenu1,'Value')

if Value==2
set(handles.text3,'String','Choose your circuit,...Right now DC')


fid=fopen(fullpathname);         % opening the input file as netlist

netlist=textscan(fid,'%s %f %f %f');

matrix=[netlist{2} netlist{3} netlist{4}];

matrix_string=[netlist{1}];

u=length(matrix_string);

p=length(find(strncmpi('i',matrix_string(1:u),1))); %number of i source

q=length(find(strncmpi('v',matrix_string(1:u),1))); %number of v source

r=length(find(strncmpi('r',matrix_string(1:u),1))); %number of resistance

R_r=find(strncmpi('r',matrix_string(1:u),1));

R_c=find(strncmpi('c',matrix_string(1:u),1));

R_l=find(strncmpi('l',matrix_string(1:u),1));

l_short=matrix(R_l,1:3);

l_short(:,3)=0;

c_open=matrix(R_c,1:3);

c_open(:,3)=0;

tgt=find(strncmpi('tgt',matrix_string(1:u),1));

I1=find(strncmpi('i',matrix_string(1:u),1));

V_v=find(strncmpi('v',matrix_string(1:u),1));

I_i=find(strncmpi('i',matrix_string(1:u),1));

if r~=0   

    mat_r=matrix(R_r,1:3) ;        %resistance matrix

end

if q ~=0

    mat_v=matrix(V_v,1:3);         %Voltage matrix

end

del=0;

mat_v=[mat_v;l_short];

mat_c=matrix(R_c,1:3);

mat_l=matrix(R_l,1:3);

mat_tgt=matrix(tgt,1:3);

node=max(max(matrix(:,1:2)));      %To find the number of node

g=zeros(node,node);

I=zeros(node,1);

mat_is=matrix(I1,1:3);            %matrix for current source

mat_is=[mat_is;c_open];

q=length(mat_v(:,1));

p=length(mat_is(:,1));

for i=1:p

    for  j=1:2
    
        if mat_is(i,j)~=0
        
            I(mat_is(i,j),1)=I(mat_is(i,j),1)+((-1)^j)*mat_is(i,3);
        
        end
        
    end
    
end

for x=1:node

    for i=1:r
    
        for j=1:2
        
            if mat_r(i,j)==x
            
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            
            end
            
        end
        
    end
    
end

for i=1:r

    x1=mat_r(i,1);
    
    x2=mat_r(i,2);
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

I

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=mat_v(i,j);
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3);

Z=[I;voltage];


X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

if mat_tgt(1,1)==0 && mat_tgt(1,2)~=0
    
    v_th=-x(mat_tgt(1,2))
    
end

if mat_tgt(1,2)==0 && mat_tgt(1,1)~=0
    
    v_th=x(mat_tgt(1,1))
    
end

if mat_tgt(1,1)~=0 && mat_tgt(1,2)~=0
    
    v_th=x(mat_tgt(1,1))-x(mat_tgt(1,2))
    
end

for i=1:r

    if mat_r(i,1)==mat_tgt(1,1) && mat_r(i,2)==mat_tgt(1,2)
    
        del=i;
        
    elseif mat_r(i,2)==mat_tgt(1,1) && mat_r(i,1)==mat_tgt(1,2)
            
            del=i;
    
    end
    
end

if del~=0

mat_r(del,:)=[];

end

mat_v=[mat_v;mat_tgt];

r=length(mat_r(:,1));

q=length(mat_v(:,1));

p=length(mat_is(:,1));

g=zeros(length(g(1,:)),length(g(1,:)));

for x=1:node

    for i=1:r
    
        for j=1:2
        
            if mat_r(i,j)==x
            
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            
            end
            
        end
        
    end
    
end

for i=1:r

    x1=mat_r(i,1);
    
    x2=mat_r(i,2);
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=mat_v(i,j);
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3);

Z=[I;voltage];

X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

i_sc=y(end)
        
r_th=v_th/i_sc

max_power=v_th^2/(4*r_th)
elseif Value==3
    
    set(handles.text3,'String','Choose your circuit,...Right now AC')
    file_name=get(handles.edit1,'String')
    fid=fopen('sch420.txt');            % opening the input file as netlist

netlist=textscan(fid,'%s %f %f %f');    

matrix=[netlist{2} netlist{3} netlist{4}];

matrix_string=[netlist{1}];

u=length(matrix_string);  

f=1000;
del=0;
p=length(find(strncmpi('i',matrix_string(1:u),1))); %number of i source

q=length(find(strncmpi('v',matrix_string(1:u),1))); %number of v source

r=length(find(strncmpi('r',matrix_string(1:u),1))); %number of resistance

R_r=find(strncmpi('r',matrix_string(1:u),1));

R_c=find(strncmpi('c',matrix_string(1:u),1));

R_l=find(strncmpi('l',matrix_string(1:u),1));

tgt=find(strncmpi('tgt',matrix_string(1:u),1));

I1=find(strncmpi('i',matrix_string(1:u),1));

V_v=find(strncmpi('v',matrix_string(1:u),1));

I_i=find(strncmpi('i',matrix_string(1:u),1));

mat_c=matrix(R_c,1:3);

mat_l=matrix(R_l,1:3);
j=sqrt(-1);
mat_c(:,3)=1./(1*j.*((mat_c(:,3)*2*pi*f)));

mat_l(:,3)=1*j.*(mat_l(:,3)*2*pi*f);


if r~=0   

    mat_r=matrix(R_r,1:3) ;        %resistance matrix

end

if q ~=0

    mat_v=matrix(V_v,1:3);         %Voltage matrix

end

mat_tgt=matrix(tgt,1:3);

node=max(max(matrix(:,1:2)));      %To find the number of node

g=zeros(node,node);

I=zeros(node,1);

mat_is=matrix(I1,1:3);            %matrix for current source

mat_r=[mat_r;mat_c;mat_l];

r=length(mat_r(:,1));
%now we will make the A matrix which is the combination of 4 matrices,
%G,B,C and D

for i=1:p
    for  j=1:2
        if real(mat_is(i,j))~=0
            I(real(mat_is(i,j)),1)=I(real(mat_is(i,j)),1)+((-1)^j)*mat_is(i,3);
        end
    end
end

for x=1:node
    for i=1:r
        for j=1:2
            if real(mat_r(i,j))==x
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            end
        end
    end
end

for i=1:r

    x1=real(mat_r(i,1));
    
    x2=real(mat_r(i,2));
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=real(mat_v(i,j));
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3)

Z=[I;voltage];

X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

if real(mat_tgt(1,1))==0 && real(mat_tgt(1,2))~=0
    
    v_th=-x(real(mat_tgt(1,2)))
    
end

if real(mat_tgt(1,2))==0 && real(mat_tgt(1,1))~=0
    
    v_th=x(real(mat_tgt(1,1)))
    
end

if real(mat_tgt(1,1))~=0 && real(mat_tgt(1,2))~=0
    
    v_th=x(real(mat_tgt(1,1)))-x(real(mat_tgt(1,2)))
    
end

for i=1:r

    if real(mat_r(i,1))==real(mat_tgt(1,1)) && real(mat_r(i,2))==real(mat_tgt(1,2))
    
        del=i;
        
    elseif real(mat_r(i,2))==real(mat_tgt(1,1)) && real(mat_r(i,1))==real(mat_tgt(1,2))
        
        del=i;
    
    end
    
end

if del~=0
    
mat_r(del,:)=[];

end

mat_v=[mat_v;mat_tgt];

r=length(mat_r(:,1));

q=length(mat_v(:,1));

p=length(mat_is(:,1));

g=zeros(node,node);

for x=1:node

    for i=1:r
    
        for j=1:2
        
            if real(mat_r(i,j))==x
            
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            
            end
            
        end
        
    end
    
end

for i=1:r

    x1=real(mat_r(i,1));
    
    x2=real(mat_r(i,2));
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=real(mat_v(i,j));
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3);

Z=[I;voltage];

X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

i_sc=y(end)
        
z_th=v_th/i_sc

max_power=((abs(v_th))^2)/(8*real(z_th))

load_for_max_power=conj(z_th)
end



