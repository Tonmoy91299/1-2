clc

clear all

close all

fid=fopen('sch420.txt');            % opening the input file as netlist
netlist=textscan(fid,'%s %f %f %f');    

matrix=[netlist{2} netlist{3} netlist{4}];

matrix_string=[netlist{1}];

u=length(matrix_string);  

f=1000;

del=0;

p=length(find(strncmpi('i',matrix_string(1:u),1))); %number of i source

q=length(find(strncmpi('v',matrix_string(1:u),1))); %number of v source

r=length(find(strncmpi('r',matrix_string(1:u),1))); %number of resistance

R_r=find(strncmpi('r',matrix_string(1:u),1));

R_c=find(strncmpi('c',matrix_string(1:u),1));

R_l=find(strncmpi('l',matrix_string(1:u),1));

tgt=find(strncmpi('tgt',matrix_string(1:u),1));

I1=find(strncmpi('i',matrix_string(1:u),1));

V_v=find(strncmpi('v',matrix_string(1:u),1));

I_i=find(strncmpi('i',matrix_string(1:u),1));

mat_c=matrix(R_c,1:3);

mat_l=matrix(R_l,1:3);

mat_c(:,3)=1./(j.*((mat_c(:,3)*2*pi*f)));

mat_l(:,3)=j.*(mat_l(:,3)*2*pi*f);


if r~=0   

    mat_r=matrix(R_r,1:3) ;        %resistance matrix

end

if q ~=0

    mat_v=matrix(V_v,1:3);         %Voltage matrix

end

mat_tgt=matrix(tgt,1:3);

node=max(max(matrix(:,1:2)));      %To find the number of node

g=zeros(node,node);

I=zeros(node,1);

mat_is=matrix(I1,1:3);            %matrix for current source

mat_r=[mat_r;mat_c;mat_l];

r=length(mat_r(:,1));
%now we will make the A matrix which is the combination of 4 matrices,
%G,B,C and D

for i=1:p
    for  j=1:2
        if real(mat_is(i,j))~=0
            I(real(mat_is(i,j)),1)=I(real(mat_is(i,j)),1)+((-1)^j)*mat_is(i,3);
        end
    end
end

for x=1:node
    for i=1:r
        for j=1:2
            if real(mat_r(i,j))==x
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            end
        end
    end
end

for i=1:r

    x1=real(mat_r(i,1));
    
    x2=real(mat_r(i,2));
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=real(mat_v(i,j));
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3)

Z=[I;voltage];

X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

if real(mat_tgt(1,1))==0 && real(mat_tgt(1,2))~=0
    
    v_th=-x(real(mat_tgt(1,2)))
    
end

if real(mat_tgt(1,2))==0 && real(mat_tgt(1,1))~=0
    
    v_th=x(real(mat_tgt(1,1)))
    
end

if real(mat_tgt(1,1))~=0 && real(mat_tgt(1,2))~=0
    
    v_th=x(real(mat_tgt(1,1)))-x(real(mat_tgt(1,2)))
    
end

for i=1:r

    if real(mat_r(i,1))==real(mat_tgt(1,1)) && real(mat_r(i,2))==real(mat_tgt(1,2))
    
        del=i;
        
    elseif real(mat_r(i,2))==real(mat_tgt(1,1)) && real(mat_r(i,1))==real(mat_tgt(1,2))
        
        del=i;
    
    end
    
end

if del~=0
    
mat_r(del,:)=[];

end

mat_v=[mat_v;mat_tgt];

r=length(mat_r(:,1));

q=length(mat_v(:,1));

p=length(mat_is(:,1));

g=zeros(node,node);

for x=1:node

    for i=1:r
    
        for j=1:2
        
            if real(mat_r(i,j))==x
            
                g(x,x)=g(x,x)+1/(mat_r(i,3));
            
            end
            
        end
        
    end
    
end

for i=1:r

    x1=real(mat_r(i,1));
    
    x2=real(mat_r(i,2));
    
    if x1~=0 && x2~=0
    
        g(x1,x2)=-1/mat_r(i,3);
        
        g(x2,x1)=-1/mat_r(i,3);
    
    end
    
end

B=zeros(node,q);

for i=1:q

    for j=1:2
    
        x_x=real(mat_v(i,j));
      
        if x_x ~=0
        
            B(x_x,i)=-(-1)^j;
      
        end
        
    end
    
end

C=B';

D=zeros(q);

A_1=[g B];

A_2=[C D];

A=[A_1;A_2];

voltage=zeros(q,1);

voltage=mat_v(1:end,3);

Z=[I;voltage];

X=A\Z;

qx=length(X)-q;

x=X(1:qx,1);

y=X(qx+1:end,1);

i_sc=y(end)
        
z_th=v_th/i_sc

max_power=((abs(v_th))^2)/(8*real(z_th))

load_for_max_power=conj(z_th)

load=1.66+5.9i;


i_i=v_th/(load+z_th);

v_load=(i_i)*(load);

con_i=conj(i_i);

complex_power=(v_load)*(con_i);

real_power=real(complex_power);

arg_1=angle(load);
pf=0.9;
arg_2=acos(pf);


if arg_1>0
    
    cap=(real_power*(tan(arg_1)-tan(arg_2)))/(2*pi*f*(((abs(v_load))/sqrt(2))^2))
    
elseif arg_1<0
    
    ind=(((abs(v_load))/sqrt(2))^2)/((2*pi*f)*(real_power*(tan(arg_1)-tan(arg_2))))
    
end

    





    